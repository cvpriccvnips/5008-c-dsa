# Homework 5

This is the starting readme for this assignment.  Please edit the following information by removing the "*edit me*" and replace it with appropriate information your assignment. If it is asking you a question, please provide a response.

- Name: *edit me*
- Github Account Name *edit me*

- How many hours did it take you to complete this assignment?
- Did you collaborate with any other students/TAs/Professors? If so, tell us who and in what capacity.
  - *edit me (add more rows if needed)*
- Did you use any external resources? (Cite them below)
  - *edit me*
  - *edit me and add more rows if needed*
- Shareable link to experiment data: *edit me*
- (Optional) What was your favorite part of the assignment?
  - *edit me*
- (Optional) How would you improve the assignment?
  - *edit me*

## Logistics

- Remember to submit your answers as a PDF to Gradescope.

## Important notes

* Do not forget, once you have pushed your changes to your repo make sure that you **submit them to Gradescope before the assignment deadline!**
